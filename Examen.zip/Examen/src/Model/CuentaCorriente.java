package Model;

import java.util.Date;

public abstract class CuentaCorriente {
    private int id;
    private Cliente cliente;
    private float saldo;
    private float limiteSaldo;
    private Date fechaApertura;
    private String estado;

    public CuentaCorriente(int id, Cliente cliente, float saldo, float limiteSaldo, Date fechaApertura, String estado) {
        this.id = id;
        this.cliente = cliente;
        this.saldo = saldo;
        this.limiteSaldo = limiteSaldo;
        this.fechaApertura = fechaApertura;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public float getLimiteSaldo() {
        return limiteSaldo;
    }

    public void setLimiteSaldo(float limiteSaldo) {
        this.limiteSaldo = limiteSaldo;
    }

    public Date getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(Date fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
