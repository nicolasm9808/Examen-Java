package Model;

import java.util.Date;

public class CuentaPersonal extends CuentaCorriente{
    //saldo maximo permitido $10.000.000
    public CuentaPersonal(int id, Cliente cliente, float saldo, float limiteSaldo, Date fechaApertura, String estado) {
        super(id, cliente, saldo, limiteSaldo, fechaApertura, estado);
    }

}
