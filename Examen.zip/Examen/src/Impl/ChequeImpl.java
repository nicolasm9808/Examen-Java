package Impl;

import DAO.ChequeDAO;

public class ChequeImpl implements ChequeDAO {
    @Override
    public void emitirCheque() {

    }

    @Override
    public void listarChequesCliente(int idCliente) {

    }

    @Override
    public void generarReporte() {

    }
}
