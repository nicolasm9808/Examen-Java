package Util;

import java.sql.*;
import java.util.Scanner;

public class Conexion {

    private static String USER = "campus2023"; //  root
    private static String PASSWORD = "campus2023"; //  1234
    private static Connection connection;

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                String url = "jdbc:mysql://localhost:3306/banco_union";
                connection = DriverManager.getConnection(url, USER, PASSWORD);
                System.out.println(url);
                System.out.println("Conectado correctamente a la base de datos");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al conectar la base de datos"+ e.getMessage());
        }
        return connection;}

    /*
    private static void ejecutar(String sql) {
        String host = "jdbc:mysql://localhost:3306/";
        String user = "root";
        String password = "campus2023";
        String db = "banco_union";
        String cadConex = host + db;

        try (Connection c = DriverManager.getConnection(cadConex, user, password);
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1,"");

            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                System.out.println(rs.getString(1));
            }


            System.out.println("Se conectó con éxito");

        } catch (SQLException ex) {
            System.err.println("Error al realizar la conexion a la BD.\n" + ex.getMessage());
        }
    }
    */

}
