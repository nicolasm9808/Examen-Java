import Impl.ClienteImpl;
import Model.Cliente;
import Service.ClienteService;

import java.util.Scanner;
import java.util.jar.JarInputStream;

public class MainTest {
    public static void main(String[] args) {
        ClienteService clienteService =  new ClienteService();

        System.out.println("------------ Sistema de Gestión Banco Unión ------------");
        Scanner scanner = new Scanner(System.in);

        System.out.print("\nIngrese su documento sin puntos ni comas: ");
        int documento = scanner.nextInt();

        Cliente cliente = clienteService.getClienteById(documento);

        System.out.println("\nBienvenido "+cliente.getNombre()+" "+cliente.getApellido());
        System.out.println("\n1) Gestor de Cuentas Corrientes");
        System.out.println("2) Gestor de Cheques");
        System.out.print("Ingrese la opcion:");

        int opc = scanner.nextInt();


        switch (opc){
            case 1:
                System.out.println("\n------------ Gestor de Cuentas Corrientes ------------");
                System.out.println("\n1) Ver las cuentas activas");
                System.out.println("2) Crear nueva cuenta");
                System.out.println("0) Volver al menú anterior");
                System.out.print("Ingrese la opcion:");
                opc = scanner.nextInt();
                switch (opc){
                    case 1:
                        System.out.println("\n"+ clienteService.listarCuentas(documento));

                        System.out.print("\nIngrese el numero de cuenta: ");
                        int cuenta = scanner.nextInt();
  
                    case 2:
                        clienteService.crearCuenta(1,"Personal");
                        break;
                    case 0:
                        break;
                }
                break;
            case 2:
                System.out.println("------------ Gestor de Cheques------------");
                System.out.print("\nIngrese el numero de cuenta: ");
                int cuenta = scanner.nextInt();

                break;



        }
    }
}
