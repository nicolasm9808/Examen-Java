package Impl;

import DAO.ClienteDAO;

import java.sql.*;
import java.util.Objects;

import Model.*;
import Util.Conexion;

public class ClienteImpl implements ClienteDAO {

    @Override
    public void crearCuenta(int id, String tipo) {
        String sql = """
                INSERT INTO `cuentas`(`id_cliente`,`tipo`,`limite_saldo`) VALUES
                (?,?,?);
                """;
        try (Connection conn = Conexion.getConnection()){
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, tipo);
            System.out.println(ps);
            if ( tipo.equals("Personal")){
                ps.setInt(3, 10000000);
            } else {
                ps.setNull(3, 0);
            }
            System.out.println(ps);
            ps.executeUpdate();

            System.out.println("Cuenta creada correctamente");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean verificarCliente(int identificacion) {
        String sql = """
                SELECT `estado` FROM `clientes`
                WHERE clientes.`identificacion` = ?;
                """;
        try (Connection conn = Conexion.getConnection()){
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, identificacion);
            ResultSet resultSet= ps.executeQuery();
            while (resultSet.next()) {
                String estado = resultSet.getString(1);
                if (estado.equals("Activo")){
                    return true;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    @Override
    public Cliente getClienteById(int identificacion) {
        String sql = """
                SELECT * FROM `clientes`
                WHERE clientes.`identificacion` = ?;

                """;
        try (Connection conn = Conexion.getConnection()){
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, identificacion);
            ResultSet resultSet= ps.executeQuery();
            while (resultSet.next()) {
                String nombre = resultSet.getString(3);
                String apellido = resultSet.getString(4);
                String direccion = resultSet.getString(5);
                String telefono = resultSet.getString(6);
                String correo = resultSet.getString(7);
                String estado = resultSet.getString(8);
                Date fechaRegistro = resultSet.getDate(9);
                Date ultimaActividad = resultSet.getDate(10);

                return new Cliente(identificacion,nombre,apellido,direccion,telefono,correo,estado,fechaRegistro,ultimaActividad);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    @Override
    public int getIdCliente(int identificacion) {
        String sql = """
                SELECT `id` FROM `clientes`
                WHERE clientes.`identificacion` = ?;

                """;
        try (Connection conn = Conexion.getConnection()){
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, identificacion);
            ResultSet resultSet= ps.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt(1);
                return id;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

    @Override
    public String listarCuentas(int id) {
        String sql = """
                SELECT id, saldo, fecha_apertura  FROM cuentas
                WHERE id_cliente = ?;
                """;
        StringBuilder cuentas= new StringBuilder();
        try (Connection conn = Conexion.getConnection()){
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet resultSet= ps.executeQuery();
            cuentas.append("IdCuenta - Saldo - Fecha de creación");
            while (resultSet.next()) {
                int idCuenta = resultSet.getInt(1);
                float saldo = resultSet.getFloat(2);
                Date fecha = resultSet.getDate(3);
                cuentas.append("\n").append(idCuenta).append(" - ").append(saldo).append(" - ").append(fecha);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return cuentas.toString();
    }
}