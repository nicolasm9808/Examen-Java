package Impl;

import DAO.CuentaDAO;

public class CuentaImpl implements CuentaDAO {
    @Override
    public void realizarDeposito() {

    }

    @Override
    public void realizarRetiro() {

    }

    @Override
    public void habilitarEmisionCheques() {

    }

    @Override
    public boolean verificarSaldo() {
        return false;
    }
}
