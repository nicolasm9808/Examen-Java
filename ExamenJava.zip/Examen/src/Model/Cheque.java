package Model;

import java.util.Date;

public class Cheque {
    private CuentaCorriente cuenta;
    private String beneficiario;
    private Float monto;
    private String montoLetras;
    private String prioridad;
    private String firmaDigital;
    private String estado;
    private String razonRechazo;
    private Date fechaEmision;
    private Date fechaProceso;
    private Boolean cobrado;
    private Float cuentaSaldoMomento;
    private Date fechaModificacion;
    private String usuarioModificacion;

    public Cheque(CuentaCorriente cuenta, String beneficiario, Float monto, String montoLetras, String prioridad, String firmaDigital, String estado, String razonRechazo, Date fechaEmision, Date fechaProceso, Boolean cobrado, Float cuentaSaldo_momento, Date fechaModificacion, String usuarioModificacion) {
        this.cuenta = cuenta;
        this.beneficiario = beneficiario;
        this.monto = monto;
        this.montoLetras = montoLetras;
        this.prioridad = prioridad;
        this.firmaDigital = firmaDigital;
        this.estado = estado;
        this.razonRechazo = razonRechazo;
        this.fechaEmision = fechaEmision;
        this.fechaProceso = fechaProceso;
        this.cobrado = cobrado;
        this.cuentaSaldoMomento = cuentaSaldo_momento;
        this.fechaModificacion = fechaModificacion;
        this.usuarioModificacion = usuarioModificacion;
    }

    public CuentaCorriente getCuenta() {
        return cuenta;
    }

    public void setCuenta(CuentaCorriente cuenta) {
        this.cuenta = cuenta;
    }

    public String getBeneficiario() {
        return beneficiario;
    }

    public void setBeneficiario(String beneficiario) {
        this.beneficiario = beneficiario;
    }

    public Float getMonto() {
        return monto;
    }

    public void setMonto(Float monto) {
        this.monto = monto;
    }

    public String getMontoLetras() {
        return montoLetras;
    }

    public void setMontoLetras(String montoLetras) {
        this.montoLetras = montoLetras;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public String getFirmaDigital() {
        return firmaDigital;
    }

    public void setFirmaDigital(String firmaDigital) {
        this.firmaDigital = firmaDigital;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getRazonRechazo() {
        return razonRechazo;
    }

    public void setRazonRechazo(String razonRechazo) {
        this.razonRechazo = razonRechazo;
    }

    public Date getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(Date fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public Date getFechaProceso() {
        return fechaProceso;
    }

    public void setFechaProceso(Date fechaProceso) {
        this.fechaProceso = fechaProceso;
    }

    public Boolean getCobrado() {
        return cobrado;
    }

    public void setCobrado(Boolean cobrado) {
        this.cobrado = cobrado;
    }

    public Float getCuentaSaldo_momento() {
        return cuentaSaldoMomento;
    }

    public void setCuentaSaldo_momento(Float cuentaSaldo_momento) {
        this.cuentaSaldoMomento = cuentaSaldo_momento;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(Date fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

    public String getUsuarioModificacion() {
        return usuarioModificacion;
    }

    public void setUsuarioModificacion(String usuarioModificacion) {
        this.usuarioModificacion = usuarioModificacion;
    }
}
