package Model;

import java.util.Date;

public class CuentaEmpresarial extends CuentaCorriente{
    //sin limite de saldo
    public CuentaEmpresarial(int id, Cliente cliente, float saldo, float limiteSaldo, Date fechaApertura, String estado) {
        super(id, cliente, saldo, limiteSaldo, fechaApertura, estado);
    }
}
