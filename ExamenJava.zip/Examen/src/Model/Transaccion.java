package Model;

import java.util.Date;

public class Transaccion {
    private int id;
    private CuentaCorriente cuenta;
    private String tipo;
    private float monto;
    private Date fecha;
    private String referencia;
    private float sladoAnterior;
    private float saldoNuevo;
    private String estado;

    public Transaccion(int id, CuentaCorriente cuenta, String tipo, float monto, Date fecha, String referencia, float sladoAnterior, float saldoNuevo, String estado) {
        this.id = id;
        this.cuenta = cuenta;
        this.tipo = tipo;
        this.monto = monto;
        this.fecha = fecha;
        this.referencia = referencia;
        this.sladoAnterior = sladoAnterior;
        this.saldoNuevo = saldoNuevo;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public CuentaCorriente getCuenta() {
        return cuenta;
    }

    public void setCuenta(CuentaCorriente cuenta) {
        this.cuenta = cuenta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public float getSladoAnterior() {
        return sladoAnterior;
    }

    public void setSladoAnterior(float sladoAnterior) {
        this.sladoAnterior = sladoAnterior;
    }

    public float getSaldoNuevo() {
        return saldoNuevo;
    }

    public void setSaldoNuevo(float saldoNuevo) {
        this.saldoNuevo = saldoNuevo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
