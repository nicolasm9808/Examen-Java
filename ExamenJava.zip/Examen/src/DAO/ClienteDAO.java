package DAO;

import Model.Cliente;

public interface ClienteDAO {
    void crearCuenta(int id, String tipo);
    boolean verificarCliente(int identificacion);
    Cliente getClienteById(int identificacion);
    int getIdCliente(int identificacion);
    String listarCuentas(int identificacion);
}
