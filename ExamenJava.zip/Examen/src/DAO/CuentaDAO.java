package DAO;

public interface CuentaDAO {
    void realizarDeposito();
    void realizarRetiro();
    void habilitarEmisionCheques();
    boolean verificarSaldo();
}
