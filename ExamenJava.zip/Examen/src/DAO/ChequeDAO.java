package DAO;

public interface ChequeDAO {
    void emitirCheque();
    void listarChequesCliente(int idCliente);
    void generarReporte();
}
