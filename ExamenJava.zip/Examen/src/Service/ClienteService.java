package Service;

import Impl.ClienteImpl;
import Model.Cliente;

public class ClienteService extends ClienteImpl {
    ClienteImpl clienteImpl = new ClienteImpl();


    public void crearCuenta(int identificacion) {
        int id = clienteImpl.getIdCliente(identificacion);
        clienteImpl.crearCuenta(id, "Personal");
    }

    public String listarCuentas(int identificacion) {
        int id = clienteImpl.getIdCliente(identificacion);
        return clienteImpl.listarCuentas(id);
    }


    public Cliente getClienteById(int identificacion) {
        return clienteImpl.getClienteById(identificacion);
    }
}
